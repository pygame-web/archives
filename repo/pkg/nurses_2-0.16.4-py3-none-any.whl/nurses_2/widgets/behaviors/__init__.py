"""
Inheritable widget behaviors.
"""