BUILTIN_LANGUAGES = sorted(
    [
        "markdown",
        "yaml",
        "sql",
        "css",
        "html",
        "json",
        "python",
        "regex",
        "toml",
    ]
)
