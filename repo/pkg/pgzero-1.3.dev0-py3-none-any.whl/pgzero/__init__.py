"""Pygame Zero, a zero-boilerplate game framework for education.

You shouldn't need to import things from the 'pgzero' package directly; just
use 'pgzrun' to run the game file.

"""

__version__ = '1.3.dev0'
