"""Make non-widget Tree support classes available."""

from ._tree import TreeNode

__all__ = ["TreeNode"]
