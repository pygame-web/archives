"""
nurses_2
========

A widgetful and async-centric terminal graphics library.
"""
__version__ = "0.18.5"
