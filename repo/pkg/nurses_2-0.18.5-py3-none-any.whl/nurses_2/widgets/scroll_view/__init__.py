"""
A scrollable view widget.
"""
from .scroll_view import ScrollView
