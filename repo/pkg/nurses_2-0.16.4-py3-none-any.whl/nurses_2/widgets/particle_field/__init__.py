"""
Particle field widgets.
"""