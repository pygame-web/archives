# __init__.py
# -*- coding: utf-8 -*-

__author__ = "grimmigerFuchs"
__version__ = "1.1.0"

import particlepy.particle
import particlepy.shape
import particlepy.math
