"""Document formats.

.. versionadded:: 1.1
"""
