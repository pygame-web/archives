"""
A 2D line plot widget.
"""
from .line_plot import LinePlot

__all__ = "LinePlot",
