"""
:mod:`nurses_2` widgets.

Widgets are basic UI components. :mod:`nurses_2.widgets` module contains classes
and functions for creating and managing widgets.
"""
