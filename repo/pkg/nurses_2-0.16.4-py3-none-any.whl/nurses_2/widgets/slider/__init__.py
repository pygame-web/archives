"""
A slider widget.
"""
from .slider import Slider
