import hpy.universal

get_call_counts = hpy.universal._trace.get_call_counts
get_durations = hpy.universal._trace.get_durations
set_trace_functions = hpy.universal._trace.set_trace_functions
get_frequency = hpy.universal._trace.get_frequency
