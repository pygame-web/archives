"""
Color-related functions and data structures.
"""
from .color_data_structures import *
from .colors import *
from .gradients import *
